const vertexData = [
    -0.5, 0.5, 0,
    -0.5, -0.5, 0,
    0.5, 0.5, 0,
    -0.5, -0.5, 0,
    0.5, 0.5, 0,
    0.5, -0.5, 0
];

let rotation = 0; // Initial rotation angle

// Get a reference to the canvas element
const canvas = document.getElementById('webgl-canvas');

// Get the WebGL rendering context
const gl = canvas.getContext('webgl');

// Check if the browser supports WebGL
if (!gl) {
    console.error('Unable to initialize WebGL. Your browser may not support it.');
} else {
    console.log('WebGL initialized successfully.');

    // Initialize Buffer
    const buffer = gl.createBuffer();

    // Bind buffer
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertexData), gl.STATIC_DRAW);

    // Create shaders
    const vertexShader = gl.createShader(gl.VERTEX_SHADER);
    const fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);

    // Set shader source
    gl.shaderSource(fragmentShader, `
        precision mediump float;
        varying vec4 fragColor;
        void main() {
            gl_FragColor = fragColor;
        }
    `);

    gl.shaderSource(vertexShader, `
        attribute vec3 position;
        varying vec4 fragColor;
        uniform mat4 modelViewMatrix;
        void main() {
            gl_Position = modelViewMatrix * vec4(position, 1);
            // Calculate color gradient based on the vertex position
            if (position.x > 0.0) {
                fragColor = vec4(1.0, 0.0, 0.0, 1.0); // Red on the right side
            } else if (position.x < 0.0) {
                fragColor = vec4(0.0, 1.0, 0.0, 1.0); // Green on the left side
            } else {
                fragColor = vec4(0.0, 0.0, 1.0, 1.0); // Blue in the center
            }
        }
    `);

    // Compile shaders
    gl.compileShader(vertexShader);
    gl.compileShader(fragmentShader);

    // Create program
    const program = gl.createProgram();

    // Attach shaders
    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);

    // Link program
    gl.linkProgram(program);

    // Get attribute location and enable it
    const positionAttributeLocation = gl.getAttribLocation(program, 'position');
    gl.enableVertexAttribArray(positionAttributeLocation);

    // Specify an attribute pointer
    gl.vertexAttribPointer(positionAttributeLocation, 3, gl.FLOAT, false, 0, 0);

    // Use the program
    gl.useProgram(program);

    // Define a function for animation
    function animate() {
        // Clear the canvas
        gl.clear(gl.COLOR_BUFFER_BIT);

        // Update the rotation angle
        rotation += 0.01;

        // Create a rotation matrix and pass it to the shader
        const cos = Math.cos(rotation);
        const sin = Math.sin(rotation);
        const rotationMatrix = new Float32Array([
            cos, -sin, 0, 0,
            sin, cos, 0, 0,
            0, 0, 1, 0,
            0, 0, 0, 1
        ]);

        const modelViewMatrixLocation = gl.getUniformLocation(program, 'modelViewMatrix');
        gl.uniformMatrix4fv(modelViewMatrixLocation, false, rotationMatrix);

        // Draw the triangle
        gl.drawArrays(gl.TRIANGLE, 0, 8);

        // Request the next animation frame
        requestAnimationFrame(animate);
    }

    // Start the animation
    animate();
}
